/*
This is the GameObjectFactory interface that allows other classes to implement the createObject() function
to create varies of game objects
*/
interface GameObjectFactory {
    GameObject createObject();
}
