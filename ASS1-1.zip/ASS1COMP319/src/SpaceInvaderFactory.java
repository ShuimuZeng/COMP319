/*
The SpaceInvaderFactory catches the behavior defined in the SpaceInvader class and Initialize the physic
initialization of the SpaceInvader object which is the character that Players control

*/
class SpaceInvaderFactory implements GameObjectFactory {

    private static int TotalLives;

    /*
    This parameter indicates the total lives the character has
    */
    public SpaceInvaderFactory(int value) {
        this.TotalLives = value;
    }

    @Override
    public GameObject createObject() {
        return new SpaceInvader();
    }
     /*
    This functions indicates the creates of the full SpaceInvader object
     */

    public int getTotalLives() {
        return TotalLives;
    }

}
