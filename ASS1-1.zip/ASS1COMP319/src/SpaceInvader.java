/*
This function extends the GameObject class and handle specific logic in details
for each type of GameObject
*/
public class SpaceInvader extends GameObject {
    @Override
    public void handle() {

    }
    /*Handle SpaceInvader logic*/
}
