/*
This class does the same extension and handling as above
but here it handles the Barrier behavior
*/
public class Barrier extends GameObject {
    @Override
    public void handle() {

    }
    /* Handle Barrier-specific game logic*/
}
