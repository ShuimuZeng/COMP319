/*
This class extends the GameObject class and handle specific Alien behaviors
*/
public class Alien extends GameObject {
    @Override
    public void handle() {

    }
    /*Handle generic Alien logic
    You can further extend this class for different alien types*/
}
