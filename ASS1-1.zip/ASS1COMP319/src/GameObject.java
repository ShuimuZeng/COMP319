/*
This pattern allows for a flexible and reusable way to build a chain of handlers,
where each handler can decide whether to process the request or pass it to the next handler in the chain.
It's particularly useful when the client doesn't need to know which object will ultimately handle the request.
*/
public abstract class GameObject {
    protected GameObject next;

    /*This field represents the reference to the next object in the chain.
    It holds the reference to the next handler that will be invoked in case
    the current handler decides not to handle the request.
    Since it's marked as protected, it can be accessed by subclasses,
    allowing them to set the next handler in the chain.
     */

    public void setNext(GameObject next) {
        this.next = next;
    }
    /*This method allows setting the next handler in the chain.
     It provides a way to link objects together dynamically,
     creating a sequence of handlers.
    */

    public abstract void handle();
    /*
    This is an abstract method that must be implemented by concrete subclasses.
    It represents the method responsible for handling the request.
    The concrete implementation of this method in each subclass decides
    whether to handle the request or pass it to the next handler in the chain.
     */
}
