import java.util.ArrayList;
import java.util.List;


/*
the GameManager class follows the Singleton pattern,
allowing a single instance to be shared and accessed globally within the application.
*/
class GameManager {
    private static GameManager instance;



    /*
    This is a private static field that holds the single instance of the GameManager class.
    It is declared as static to ensure that there is only one
    instance shared among all instances of the class.
    */

    private GameManager() {
        // Private constructor to enforce singleton pattern

    }
    /*
    This is a private constructor. By making the constructor private,
    the class prevents external code from creating new instances of the GameManager directly.
    */

    public static GameManager getInstance() {
        if (instance == null) {
            instance = new GameManager();
        }
        return instance;
    }
    /*
    This is a public static method,
    responsible for providing access to the single instance of the class.
    If an instance doesn't exist, it creates one;
    otherwise, it returns the existing instance.
    The method uses a lazy initialization approach,
    creating the instance only when it's needed for the first time.
     */
    public void LivesManagement(){
        /*Here is to manage the current lives */

    }
    /*
    The two functions are displayed for simplification of the complex logic to decide whether to stop the game
    or continue
     */
    public int getLives(){
        SpaceInvaderFactory lives = new SpaceInvaderFactory(3);
        return lives.getTotalLives();
    }
    public void startGame() {
        // Implement game initialization logic
    }
    /*
    This is an example method that represents some functionality of the GameManager class.
    In this case, it's startGame(), which presumably
    contains the logic to initialize and start the game.
     */
    private void endGame() {
        System.out.println("Game Over! Try Again?");

    }
    /*Implement game over logic, e.g., display score, ask for restart, etc.*/
    public void restartGame() {

        startGame();
    }
    /*
    here is the function to reset the lives and restart the game
     */
}


// Single Responsibility Principle - Separate classes for displaying and managing game state
/*
Here we initialize the way that we are going to display the game
*/
class GameDisplay {



    public void display(List<GameObject> gameObjects) {

    }
    // Stub: Implement logic to display the game state and the location of GameObjects
    public void displaySound(){

    }
    /*Sound effect logics here*/
}

/* Score class to handle current score and highest score
*/
class Score {
    private int currentScore;
    /*
    the current score every time palyers play
     */
    private int highestScore;
    /*
    the highest score of the game that players ever played
     */

    public Score() {
        this.currentScore = 0;
        this.highestScore = 0;
    }
    /*
    Initialize the scores to 0
     */

    public int getCurrentScore() {
        return currentScore;
    }
    /*We get the current score Players play here*/

    public void increaseScore(int points) {
        currentScore += points;//Here is a simplified score increasing logic
        if (currentScore > highestScore) {
            highestScore = currentScore;
        }
        /*
        Everytime theSpaceInvader beats an enemy, points will be caught in the behavior section and will
        be delivered here for the calculation of the current score
         */
    }

    public int getHighestScore() {
        return highestScore;
    }
    /*
    The function lets us get the highestScore
     */
}

// UI Class
/*This is the initialization of the game UI interface*/
class GameUI {

    public GameUI gameUI;
    /*Set the UI as a variable*/
    public void render(List<GameObject> gameObjects) {

        for (GameObject gameObject : gameObjects) {
            System.out.println("Rendering: " + gameObject.getClass().getSimpleName());
        }
    }
    /*Implement UI rendering logic here
    For simplicity, we print a message for each game object*/

}
/*
This class is the one that receives certain objects and displays them in a certain logic
 */
class GameController extends GameUI {
    private List<GameObject> gameObjects;
    /*
    this is the list of bojects
     */
    public GameDisplay display;

    /*
    this is the display object for sound effect display and objects display
     */

    public Score score;

    /*
    here is the score object for counting the scores needed on the UI
     */

    public SpaceInvaderFactory spaceInvader;

    /*
    this is the full spaceInvader object
     */

    private AlienFactory alien;
    /*
    this is the full Alien object
     */
    private BarrierFactory barrier;
    /*
    this is the full Barrier object
     */
    private Bullet bullet;
    /*
    this is the Bullet object
     */
    private BombAlien bombAlien;
    /*
    this is the bomb object
     */

    public GameController(GameUI gameUI) {
        this.gameUI = gameUI;

        initializeGame();
        gameObjects = new ArrayList<>();
        gameUI.render(gameObjects);
        display = new GameDisplay();
        score = new Score();
        spaceInvader = new SpaceInvaderFactory(3);
        alien = new AlienFactory();
        alien.createObject();
        bullet = new Bullet();
        barrier = new BarrierFactory();
        bombAlien = new BombAlien();
        score.getCurrentScore();
        score.getHighestScore();
        display.displaySound();
        display.display(gameObjects);

    }
    /*
    This function is the exact controller of what the users will see. All the objects and their certain
    behavior is introduced and will be arranged properly
     */

    private void initializeGame() {

    }
    /*Add barriers, initialize scores, and other game setup...*/
    public void play() {
        // Game loop logic
        while (GameManager.getInstance().getLives() > 0) {
            for (GameObject gameObject : gameObjects) {
                gameObject.handle();
            }
            GameManager.getInstance().LivesManagement();
        }
        // When lives become 0, the game loop exits
        System.out.println("Game Over! Restarting...");
        GameManager.getInstance().restartGame();
        play();  // Restart the game
    }
    /*
    This is a simple implementation of the judgement of continuing or restart.
     */
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        GameManager.getInstance().startGame();
        // Initialize UI
        GameUI gameUI = new GameUI();
        GameController gameController = new GameController(gameUI);
        gameController.play();
    }
}