public abstract class Weapon {
    public abstract void Weaponhandle();
}
/*
    Initialization of weapons
     */

class weaponname implements Weapons{
    /*
    Add something for implementation
     */
}

