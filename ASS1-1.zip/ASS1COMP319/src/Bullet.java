// Open Closed Principle - Extension through inheritance
/*
Here handles Bullets that are fired by the character space invader
*/
public class Bullet extends Weapon {
    @Override
    public void Weaponhandle() {

    }
    /*
     Handle Bullet logic
    */
}
