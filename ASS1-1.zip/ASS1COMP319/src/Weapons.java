public interface Weapons{
   /*
   abstraction of varies of weapons
    */
}
