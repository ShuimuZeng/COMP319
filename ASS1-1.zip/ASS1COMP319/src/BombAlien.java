public class BombAlien extends Weapon {
    @Override
    public void Weaponhandle() {

    }
    /*Handle the Bomb logic*/
}
