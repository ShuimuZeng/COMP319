/*
Enum to represent different types of aliens
*/
enum AlienType {
    TYPE_A,
    TYPE_B,
    TYPE_C
}
