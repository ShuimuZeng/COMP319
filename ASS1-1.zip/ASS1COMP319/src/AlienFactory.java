/*
The AlienFactory class catches the Alien behavior logic and initialize the Alien

*/
public class AlienFactory implements GameObjectFactory {

    @Override
    public GameObject createObject() {
        // Choose a random alien type or implement my own logic
        AlienType type = getRandomAlienType();
        return new Alien();
    }
    /*
        The function here introduces the AlienType and is supposed to create Alien objects and their behaviors
        */


    private AlienType getRandomAlienType() {
        return AlienType.TYPE_A;
    }
    /* Implement logic to get a random alien type
         For simplicity, you can choose randomly or implement your own strategy
        For example, return AlienType.TYPE_A;
        */
}
