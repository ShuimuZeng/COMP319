/*

The BarrierFactory is supposed to initialize the Barriers and catches the logic behavior of the Barriers

*/
public class BarrierFactory implements GameObjectFactory {

    private static final int NumberForBarrier = 3;
    /*we only set three barriers here*/

    @Override
    public GameObject createObject() {
        return new Barrier();


    }
    /*
    This function creates barriers and catches the defined behaviors
    */
}
